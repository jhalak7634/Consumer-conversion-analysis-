import streamlit as st
import pandas as pd
import numpy as np
import os
import joblib
import json
import matplotlib.pyplot as plt
import seaborn as sns

# Set page config
st.set_page_config(
    page_title="Customer Conversion Predictor",
    page_icon="🔮",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Custom CSS for rich aesthetics and glassmorphism styling
st.markdown("""
<style>
    @import url('https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap');
    
    /* Global font overrides */
    html, body, [class*="css"] {
        font-family: 'Inter', sans-serif !important;
    }
    
    /* Card design */
    .premium-card {
        background: linear-gradient(135deg, #1e293b 0%, #0f172a 100%);
        border: 1px solid #334155;
        border-radius: 16px;
        padding: 24px;
        margin-bottom: 20px;
        box-shadow: 0 10px 15px -3px rgba(0, 0, 0, 0.3);
    }
    
    .gradient-header {
        background: linear-gradient(90deg, #38bdf8, #818cf8);
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        font-weight: 700;
        font-size: 2.2rem;
        margin-bottom: 0.5rem;
        text-align: center;
    }
    
    .sub-header {
        color: #94a3b8;
        font-size: 1.1rem;
        text-align: center;
        margin-bottom: 2rem;
    }
    
    .metric-val {
        font-size: 2.5rem;
        font-weight: 700;
        color: #38bdf8;
        text-shadow: 0 0 10px rgba(56, 189, 248, 0.2);
    }
    
    .metric-label {
        font-size: 0.85rem;
        color: #94a3b8;
        text-transform: uppercase;
        letter-spacing: 0.05em;
        font-weight: 600;
    }
    
    .success-container {
        border-left: 5px solid #10b981;
        background-color: #064e3b;
        padding: 15px;
        border-radius: 8px;
        margin-top: 15px;
    }
    
    .failure-container {
        border-left: 5px solid #ef4444;
        background-color: #7f1d1d;
        padding: 15px;
        border-radius: 8px;
        margin-top: 15px;
    }
</style>
""", unsafe_allow_html=True)

# Helper functions
@st.cache_resource
def load_pipeline():
    model_path = 'models/best_model_pipeline.joblib'
    if os.path.exists(model_path):
        return joblib.load(model_path)
    return None

@st.cache_data
def load_metrics():
    metrics_path = 'models/metrics.json'
    if os.path.exists(metrics_path):
        with open(metrics_path, 'r') as f:
            return json.load(f)
    return None

@st.cache_data
def load_raw_data():
    if os.path.exists('train.csv'):
        return pd.read_csv('train.csv')
    return None

# Load cached components
pipeline = load_pipeline()
metrics = load_metrics()
df_raw = load_raw_data()

# Header Section
st.markdown("<div class='gradient-header'>🔮 Insurance Customer Conversion Platform</div>", unsafe_allow_html=True)
st.markdown("<div class='sub-header'>Predict, analyze, and optimize outreach campaigns for term insurance subscription</div>", unsafe_allow_html=True)

# Sidebar layout
st.sidebar.markdown("### Platform Controls")
st.sidebar.info("Use the tabs below to explore the data, check model performance, or test conversion likelihood for new prospects.")

# Main Navigation
tab_overview, tab_predict, tab_batch, tab_metrics = st.tabs([
    "📊 Dataset Overview & EDA", 
    "🎯 Single Client Predictor", 
    "📂 Batch File Predictor", 
    "📈 Model Diagnostics"
])

# -----------------
# TAB 1: OVERVIEW & EDA
# -----------------
with tab_overview:
    st.markdown("### 📊 Exploratory Data Analysis & Insights")
    
    if df_raw is not None:
        col_m1, col_m2, col_m3, col_m4 = st.columns(4)
        
        with col_m1:
            st.markdown(f"<div class='premium-card'><div class='metric-label'>Total Prospects</div><div class='metric-val'>{len(df_raw):,}</div></div>", unsafe_allow_html=True)
        with col_m2:
            sub_count = (df_raw['y'] == 'yes').sum()
            st.markdown(f"<div class='premium-card'><div class='metric-label'>Total Subscribed</div><div class='metric-val'>{sub_count:,}</div></div>", unsafe_allow_html=True)
        with col_m3:
            sub_rate = (df_raw['y'] == 'yes').mean() * 100
            st.markdown(f"<div class='premium-card'><div class='metric-label'>Conversion Rate</div><div class='metric-val'>{sub_rate:.2f}%</div></div>", unsafe_allow_html=True)
        with col_m4:
            st.markdown(f"<div class='premium-card'><div class='metric-label'>Outreach Features</div><div class='metric-val'>{df_raw.shape[1] - 1} Columns</div></div>", unsafe_allow_html=True)

        col_c1, col_c2 = st.columns(2)
        
        with col_c1:
            st.markdown("#### Call Duration vs Subscription")
            fig, ax = plt.subplots(figsize=(8, 4))
            # Set background dark slate for consistency
            fig.patch.set_facecolor('#0f172a')
            ax.set_facecolor('#1e293b')
            
            sns.histplot(data=df_raw, x='dur', hue='y', multiple='stack', bins=30, ax=ax, palette=['#ef4444', '#10b981'])
            ax.set_title("Distribution of Call Duration (Seconds)", color='#f8fafc', fontsize=11, fontweight='bold')
            ax.set_xlabel("Duration (seconds)", color='#94a3b8')
            ax.set_ylabel("Count", color='#94a3b8')
            ax.tick_params(colors='#94a3b8')
            for spine in ax.spines.values():
                spine.set_color('#334155')
            st.pyplot(fig)
            st.caption("Insight: Customers with call durations exceeding 5 minutes (300s) are significantly more likely to subscribe. Shorter calls have extremely poor conversion.")

        with col_c2:
            st.markdown("#### Conversion Rate by Job Type")
            # Calculate conversion rates
            job_conv = df_raw.groupby('job')['y'].apply(lambda x: (x == 'yes').mean() * 100).reset_index()
            job_conv = job_conv.sort_values(by='y', ascending=False)
            
            fig, ax = plt.subplots(figsize=(8, 4))
            fig.patch.set_facecolor('#0f172a')
            ax.set_facecolor('#1e293b')
            
            sns.barplot(data=job_conv, x='y', y='job', ax=ax, palette='viridis')
            ax.set_title("Conversion Rate (%) by Job Role", color='#f8fafc', fontsize=11, fontweight='bold')
            ax.set_xlabel("Conversion Rate (%)", color='#94a3b8')
            ax.set_ylabel("Job Role", color='#94a3b8')
            ax.tick_params(colors='#94a3b8')
            for spine in ax.spines.values():
                spine.set_color('#334155')
            st.pyplot(fig)
            st.caption("Insight: Students and retired individuals show the highest subscription rates, although they constitute a smaller portion of the total targets.")

        # Additional demographics overview
        st.markdown("#### Quick Dataset Sample")
        st.dataframe(df_raw.head(10), use_container_width=True)

    else:
        st.warning("Could not load train.csv for EDA. Please verify that train.csv exists in the root directory.")

# -----------------
# TAB 2: SINGLE PREDICTOR
# -----------------
with tab_predict:
    st.markdown("### 🎯 Predict Conversion Likelihood for a Prospect")
    
    if pipeline is None:
        st.warning("⚠️ Machine Learning model is not available. Please run `train_pipeline.py` first to train and serialize the model.")
    else:
        # Form layout
        st.markdown("<div class='premium-card'>", unsafe_allow_html=True)
        col1, col2, col3 = st.columns(3)
        
        with col1:
            st.markdown("##### 👤 Demographics")
            age = st.slider("Age", 18, 95, 35)
            job = st.selectbox("Job Type", [
                'management', 'technician', 'entrepreneur', 'blue-collar', 
                'retired', 'admin.', 'services', 'self-employed', 
                'unemployed', 'housemaid', 'student', 'unknown'
            ])
            marital = st.selectbox("Marital Status", ['married', 'single', 'divorced'])
            education = st.selectbox("Education Level", ['primary', 'secondary', 'tertiary', 'unknown'])
            
        with col2:
            st.markdown("##### 📞 Current Campaign Outreach")
            call_type = st.selectbox("Contact Communication Type", ['cellular', 'telephone', 'unknown'])
            day = st.slider("Day of Month Last Contacted", 1, 31, 15)
            month = st.selectbox("Month Last Contacted", [
                'jan', 'feb', 'mar', 'apr', 'may', 'jun', 
                'jul', 'aug', 'sep', 'oct', 'nov', 'dec'
            ])
            
        with col3:
            st.markdown("##### ⏱️ Campaign Interactions")
            dur = st.number_input("Last Contact Duration (seconds)", min_value=0, max_value=5000, value=120)
            num_calls = st.slider("Number of Contacts in Current Campaign", 1, 50, 1)
            prev_outcome = st.selectbox("Previous Campaign Outcome", ['unknown', 'failure', 'other', 'success'])
            
        st.markdown("</div>", unsafe_allow_html=True)
        
        # Build Input DataFrame
        input_data = pd.DataFrame([{
            'age': age,
            'job': job,
            'marital': marital,
            'education_qual': education,
            'call_type': call_type,
            'day': day,
            'mon': month,
            'dur': dur,
            'num_calls': num_calls,
            'prev_outcome': prev_outcome
        }])

        if st.button("🔮 Analyze Prospect Conversion", use_container_width=True):
            # Run prediction
            prob = pipeline.predict_proba(input_data)[0][1]
            pred = pipeline.predict(input_data)[0]
            
            st.markdown("### Analysis Results")
            col_res1, col_res2 = st.columns([1, 2])
            
            with col_res1:
                # Dynamic prediction card
                if prob >= 0.5:
                    st.markdown(f"""
                    <div class='success-container'>
                        <h3 style='margin:0;color:#f8fafc;'>✅ Conversion Likely</h3>
                        <p style='margin:10px 0 0 0;font-size:1.1rem;color:#f8fafc;'>
                            Likelihood: <strong>{prob*100:.1f}%</strong>
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                else:
                    st.markdown(f"""
                    <div class='failure-container'>
                        <h3 style='margin:0;color:#f8fafc;'>❌ Conversion Unlikely</h3>
                        <p style='margin:10px 0 0 0;font-size:1.1rem;color:#f8fafc;'>
                            Likelihood: <strong>{prob*100:.1f}%</strong>
                        </p>
                    </div>
                    """, unsafe_allow_html=True)
                    
            with col_res2:
                # Recommendations
                st.markdown("#### 💡 Campaign Strategy Recommendations")
                recs = []
                if dur < 180:
                    recs.append("🔴 **Short Contact Duration:** The current call duration is under 3 minutes. Telephonic outreach requires building rapport; recommend training agents to prolong engagement beyond 300 seconds.")
                if prev_outcome == 'success':
                    recs.append("🟢 **Prior Success:** The prospect subscribed to a policy in a previous campaign. Prior conversion is the strongest indicator of subsequent conversion. Priority outreach recommended.")
                if month == 'may':
                    recs.append("🟡 **Seasonality Effect:** The month of May typically experiences high volume but low percentage conversions. Consider reallocation of outreach budgets towards March or September which have historically higher success rates.")
                if num_calls > 3:
                    recs.append("🟡 **Campaign Fatigue:** Contacting the customer more than 3 times during a single campaign shows diminishing returns and risks customer annoyance. Halt outreach and try in the next campaign cycle.")
                
                if not recs:
                    recs.append("✨ **Optimal Parameters:** The prospect is within high-converting target groups. Normal campaign follow-up procedures apply.")
                    
                for rec in recs:
                    st.markdown(rec)

# -----------------
# TAB 3: BATCH PREDICTOR
# -----------------
with tab_batch:
    st.markdown("### 📂 Batch Conversion Predictions")
    st.markdown("Upload a CSV file containing prospect details. The file must contain columns matching the dataset features: `age`, `job`, `marital`, `education_qual`, `call_type`, `day`, `mon`, `dur`, `num_calls`, `prev_outcome`.")
    
    if pipeline is None:
        st.warning("⚠️ Machine Learning model is not available. Please run `train_pipeline.py` first.")
    else:
        uploaded_file = st.file_uploader("Choose a CSV file", type="csv")
        
        if uploaded_file is not None:
            batch_df = pd.read_csv(uploaded_file)
            st.success(f"Successfully loaded file containing {len(batch_df)} rows.")
            
            # Verify features
            required_cols = ['age', 'job', 'marital', 'education_qual', 'call_type', 'day', 'mon', 'dur', 'num_calls', 'prev_outcome']
            missing_cols = [col for col in required_cols if col not in batch_df.columns]
            
            if len(missing_cols) > 0:
                st.error(f"The uploaded file is missing the following required columns: {missing_cols}")
            else:
                if st.button("🔮 Run Batch Prediction", use_container_width=True):
                    # Run predictions
                    predictions = pipeline.predict(batch_df[required_cols])
                    probabilities = pipeline.predict_proba(batch_df[required_cols])[:, 1]
                    
                    # Append results
                    result_df = batch_df.copy()
                    result_df['predicted_subscription'] = np.where(predictions == 1, 'yes', 'no')
                    result_df['subscription_probability'] = np.round(probabilities * 100, 2)
                    
                    st.markdown("#### Prediction Preview")
                    st.dataframe(result_df[['age', 'job', 'dur', 'predicted_subscription', 'subscription_probability']].head(20), use_container_width=True)
                    
                    # Create downloadable CSV
                    csv_data = result_df.to_csv(index=False).encode('utf-8')
                    st.download_button(
                        label="📥 Download Complete Predictions CSV",
                        data=csv_data,
                        file_name="prospect_predictions.csv",
                        mime="text/csv",
                        use_container_width=True
                    )

# -----------------
# TAB 4: METRICS & DIAGNOSTICS
# -----------------
with tab_metrics:
    st.markdown("### 📈 Model Performance & Diagnostic Charts")
    
    if metrics is None:
        st.warning("⚠️ Metrics are not available yet. Run the training pipeline (`train_pipeline.py`) first to populate model metrics.")
    else:
        st.markdown(f"#### Best Selected Model: **{metrics['best_model']}**")
        
        # Display overall scores in metrics grid
        scores = metrics['test_metrics'][metrics['best_model']]
        col_s1, col_s2, col_s3, col_s4 = st.columns(4)
        
        with col_s1:
            st.markdown(f"<div class='premium-card'><div class='metric-label'>AUROC Metric</div><div class='metric-val'>{scores['auroc']:.4f}</div></div>", unsafe_allow_html=True)
        with col_s2:
            st.markdown(f"<div class='premium-card'><div class='metric-label'>Accuracy</div><div class='metric-val'>{scores['accuracy']:.4f}</div></div>", unsafe_allow_html=True)
        with col_s3:
            st.markdown(f"<div class='premium-card'><div class='metric-label'>F1-Score</div><div class='metric-val'>{scores['f1_score']:.4f}</div></div>", unsafe_allow_html=True)
        with col_s4:
            st.markdown(f"<div class='premium-card'><div class='metric-label'>Recall (Sensitivity)</div><div class='metric-val'>{scores['recall']:.4f}</div></div>", unsafe_allow_html=True)

        # Plot comparison
        st.markdown("#### Diagnostic Visualization Plots")
        col_img1, col_img2 = st.columns(2)
        
        with col_img1:
            if os.path.exists('plots/roc_curves.png'):
                st.image('plots/roc_curves.png', caption="ROC Curve Comparison - All Tuned Models", use_container_width=True)
            else:
                st.info("ROC Curve image not found.")
                
            if os.path.exists('plots/confusion_matrix.png'):
                st.image('plots/confusion_matrix.png', caption="Confusion Matrix - Best Model on Test Set", use_container_width=True)
            else:
                st.info("Confusion Matrix image not found.")

        with col_img2:
            if os.path.exists('plots/feature_importance.png'):
                st.image('plots/feature_importance.png', caption="Feature Importance / Coefficients magnitude", use_container_width=True)
            else:
                st.info("Feature Importance plot not found.")

        # Show all model metrics table
        st.markdown("#### Full Model Comparison Matrix")
        metrics_df = pd.DataFrame(metrics['test_metrics']).T
        st.table(metrics_df)
