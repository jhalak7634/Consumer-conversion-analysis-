import pandas as pd
import numpy as np
import os
import joblib
import json
from sklearn.model_selection import train_test_split, GridSearchCV, StratifiedKFold
from src.preprocessing import clean_data
from src.models import get_models_and_grids
from src.evaluation import evaluate_model, plot_roc_curves, plot_confusion_matrix, plot_feature_importance

def main():
    print("Starting Customer Conversion Prediction training pipeline...")
    
    # 1. Load data
    data_path = 'train.csv'
    if not os.path.exists(data_path):
        data_path = os.path.join(os.path.dirname(__file__), 'train.csv') if '__file__' in locals() else 'train.csv'
        
    print(f"Loading data from {data_path}...")
    df = pd.read_csv(data_path)
    print(f"Original dataset shape: {df.shape}")

    # 2. Clean data
    df_clean = clean_data(df)
    print(f"Dataset shape after removing duplicates: {df_clean.shape}")

    # 3. Extract features and target
    features = ['age', 'job', 'marital', 'education_qual', 'call_type', 'day', 'mon', 'dur', 'num_calls', 'prev_outcome']
    target = 'target'
    
    X = df_clean[features]
    y = df_clean[target]

    print(f"Class distribution: {y.value_counts(normalize=True).to_dict()}")

    # 4. Stratified Train-Test Split
    X_train, X_test, y_train, y_test = train_test_split(
        X, y, test_size=0.2, random_state=42, stratify=y
    )
    print(f"Training set size: {X_train.shape[0]}")
    print(f"Test set size: {X_test.shape[0]}")

    # 5. Load models and parameter grids
    models, grids = get_models_and_grids()

    # Create directories for output artifacts
    os.makedirs('models', exist_ok=True)
    os.makedirs('plots', exist_ok=True)

    fitted_models = {}
    test_metrics = {}

    cv = StratifiedKFold(n_splits=5, shuffle=True, random_state=42)

    # 6. Train and tune models
    for name, model in models.items():
        print(f"\nTuning and training {name}...")
        grid_search = GridSearchCV(
            estimator=model,
            param_grid=grids[name],
            scoring='roc_auc',
            cv=cv,
            n_jobs=-1,
            verbose=1
        )
        grid_search.fit(X_train, y_train)
        
        best_model = grid_search.best_estimator_
        fitted_models[name] = best_model
        
        print(f"Best parameters for {name}: {grid_search.best_params_}")
        print(f"Best CV AUROC score: {grid_search.best_score_:.4f}")

        # Evaluate on test set
        metrics, y_pred, y_proba = evaluate_model(best_model, X_test, y_test)
        test_metrics[name] = metrics
        print(f"Test AUROC for {name}: {metrics['auroc']:.4f}")
        print(f"Test F1-Score for {name}: {metrics['f1_score']:.4f}")

    # 7. Print comparative results
    print("\n" + "="*50)
    print("MODEL COMPARISON ON HELD-OUT TEST DATA")
    print("="*50)
    metrics_df = pd.DataFrame(test_metrics).T
    print(metrics_df.to_string())
    print("="*50)

    # 8. Select best model based on AUROC
    best_model_name = max(test_metrics, key=lambda k: test_metrics[k]['auroc'])
    best_model = fitted_models[best_model_name]
    print(f"\nBest model selected: {best_model_name} with AUROC = {test_metrics[best_model_name]['auroc']:.4f}")

    # 9. Save Best Model and preprocessor pipeline
    model_save_path = 'models/best_model_pipeline.joblib'
    print(f"Saving the best model pipeline to {model_save_path}...")
    joblib.dump(best_model, model_save_path)

    # Save metrics JSON
    metrics_save_path = 'models/metrics.json'
    summary = {
        'best_model': best_model_name,
        'test_metrics': test_metrics,
        'features': features
    }
    with open(metrics_save_path, 'w') as f:
        json.dump(summary, f, indent=4)

    # 10. Generate and save plots
    print("Generating evaluation plots...")
    
    # ROC curves comparison
    plot_roc_curves(fitted_models, X_test, y_test, 'plots/roc_curves.png')
    
    # Best model confusion matrix
    best_y_pred = best_model.predict(X_test)
    plot_confusion_matrix(y_test, best_y_pred, 'plots/confusion_matrix.png')
    
    # Best model feature importance
    plot_feature_importance(best_model, 'plots/feature_importance.png')
    
    print("\nTraining and evaluation pipeline completed successfully!")

if __name__ == '__main__':
    main()
