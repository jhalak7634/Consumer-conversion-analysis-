from sklearn.linear_model import LogisticRegression
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from xgboost import XGBClassifier
from imblearn.pipeline import Pipeline as ImbPipeline
from imblearn.combine import SMOTEENN
from src.preprocessing import get_preprocessor

def get_models_and_grids():
    """
    Returns a dictionary of models (imbalanced-learn pipelines) and their 
    hyperparameter grids for grid search.
    """
    preprocessor = get_preprocessor()
    
    # We use ImbPipeline so SMOTEENN is only applied to the training folds 
    # of the cross-validation, preventing data leakage to validation folds.
    models = {
        'LogisticRegression': ImbPipeline([
            ('preprocessor', preprocessor),
            ('smoteenn', SMOTEENN(random_state=42)),
            ('classifier', LogisticRegression(max_iter=1000, random_state=42))
        ]),
        'DecisionTree': ImbPipeline([
            ('preprocessor', preprocessor),
            ('smoteenn', SMOTEENN(random_state=42)),
            ('classifier', DecisionTreeClassifier(random_state=42))
        ]),
        'RandomForest': ImbPipeline([
            ('preprocessor', preprocessor),
            ('smoteenn', SMOTEENN(random_state=42)),
            ('classifier', RandomForestClassifier(random_state=42, n_jobs=-1))
        ]),
        'XGBoost': ImbPipeline([
            ('preprocessor', preprocessor),
            ('smoteenn', SMOTEENN(random_state=42)),
            ('classifier', XGBClassifier(random_state=42, eval_metric='logloss', n_jobs=-1))
        ])
    }

    grids = {
        'LogisticRegression': {
            'classifier__C': [0.01, 0.1, 1.0, 10.0]
        },
        'DecisionTree': {
            'classifier__max_depth': [3, 5, 8, 12],
            'classifier__min_samples_split': [2, 5, 10]
        },
        'RandomForest': {
            'classifier__max_depth': [5, 8, 12],
            'classifier__n_estimators': [100, 200]
        },
        'XGBoost': {
            'classifier__learning_rate': [0.05, 0.1, 0.2],
            'classifier__max_depth': [3, 5, 7],
            'classifier__n_estimators': [100, 150]
        }
    }
    
    return models, grids
