import pandas as pd
import numpy as np
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.compose import ColumnTransformer
from sklearn.preprocessing import StandardScaler, OneHotEncoder, OrdinalEncoder
from sklearn.pipeline import Pipeline

class OutlierClipper(BaseEstimator, TransformerMixin):
    """
    Clips numeric values to IQR bounds. IQR bounds are computed during fit
    to avoid data leakage.
    """
    def __init__(self):
        self.lower_bounds_ = None
        self.upper_bounds_ = None

    def fit(self, X, y=None):
        X_arr = np.array(X, dtype=float)
        self.lower_bounds_ = []
        self.upper_bounds_ = []
        for i in range(X_arr.shape[1]):
            q1, q3 = np.percentile(X_arr[:, i], [25, 75])
            iqr = q3 - q1
            self.lower_bounds_.append(q1 - 1.5 * iqr)
            self.upper_bounds_.append(q3 + 1.5 * iqr)
        return self

    def transform(self, X):
        X_arr = np.array(X, dtype=float)
        for i in range(X_arr.shape[1]):
            X_arr[:, i] = np.clip(X_arr[:, i], self.lower_bounds_[i], self.upper_bounds_[i])
        return X_arr

def get_preprocessor():
    """
    Creates and returns a ColumnTransformer for feature preprocessing.
    """
    numeric_features = ['age', 'day', 'dur', 'num_calls']
    ordinal_features = ['education_qual', 'mon']
    nominal_features = ['job', 'marital', 'call_type', 'prev_outcome']

    # Ordinal categories specification
    education_categories = ['unknown', 'primary', 'secondary', 'tertiary']
    month_categories = ['jan', 'feb', 'mar', 'apr', 'may', 'jun', 'jul', 'aug', 'sep', 'oct', 'nov', 'dec']

    numeric_transformer = Pipeline(steps=[
        ('clipper', OutlierClipper()),
        ('scaler', StandardScaler())
    ])

    ordinal_transformer = OrdinalEncoder(
        categories=[education_categories, month_categories],
        handle_unknown='use_encoded_value',
        unknown_value=-1
    )

    nominal_transformer = OneHotEncoder(
        handle_unknown='ignore',
        sparse_output=False
    )

    preprocessor = ColumnTransformer(
        transformers=[
            ('num', numeric_transformer, numeric_features),
            ('ord', ordinal_transformer, ordinal_features),
            ('nom', nominal_transformer, nominal_features)
        ],
        remainder='drop'
    )
    return preprocessor

def clean_data(df):
    """
    Loads, cleans duplicates, and prepares target variable for modelling.
    """
    df_clean = df.copy()
    
    # 1. Drop duplicates
    df_clean = df_clean.drop_duplicates()
    
    # 2. Treat target
    if 'y' in df_clean.columns:
        df_clean['target'] = df_clean['y'].map({'yes': 1, 'no': 0})
        
    return df_clean
