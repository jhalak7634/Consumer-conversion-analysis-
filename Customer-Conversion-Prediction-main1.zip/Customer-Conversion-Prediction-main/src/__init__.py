# Package initializer for customer conversion prediction pipeline
