import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
import os
from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, confusion_matrix, roc_curve
)

def evaluate_model(model, X_test, y_test):
    """
    Calculates classification metrics on test data.
    """
    y_pred = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    metrics = {
        'accuracy': accuracy_score(y_test, y_pred),
        'precision': precision_score(y_test, y_pred),
        'recall': recall_score(y_test, y_pred),
        'f1_score': f1_score(y_test, y_pred),
        'auroc': roc_auc_score(y_test, y_proba)
    }
    return metrics, y_pred, y_proba

def get_feature_names(preprocessor):
    """
    Extracts feature names from the fitted ColumnTransformer.
    """
    numeric_features = ['age', 'day', 'dur', 'num_calls']
    ordinal_features = ['education_qual', 'mon']
    nominal_features = ['job', 'marital', 'call_type', 'prev_outcome']

    # Get One-Hot encoded feature names
    ohe = preprocessor.named_transformers_['nom']
    ohe_features = list(ohe.get_feature_names_out(nominal_features))

    return numeric_features + ordinal_features + ohe_features

def plot_roc_curves(models_dict, X_test, y_test, save_path):
    """
    Plots the ROC curves for all models in a single chart.
    """
    plt.figure(figsize=(10, 8), dpi=150)
    for name, model in models_dict.items():
        y_proba = model.predict_proba(X_test)[:, 1]
        fpr, tpr, _ = roc_curve(y_test, y_proba)
        auc_score = roc_auc_score(y_test, y_proba)
        plt.plot(fpr, tpr, label=f"{name} (AUROC = {auc_score:.3f})")

    plt.plot([0, 1], [0, 1], 'k--', label="Random (AUROC = 0.500)")
    plt.xlabel("False Positive Rate", fontsize=12)
    plt.ylabel("True Positive Rate", fontsize=12)
    plt.title("ROC Curves Comparison", fontsize=14, fontweight='bold')
    plt.legend(loc="lower right")
    plt.grid(True, linestyle='--', alpha=0.6)
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()

def plot_confusion_matrix(y_true, y_pred, save_path):
    """
    Plots confusion matrix heat map.
    """
    cm = confusion_matrix(y_true, y_pred)
    plt.figure(figsize=(6, 5), dpi=150)
    sns.heatmap(cm, annot=True, fmt='d', cmap='Blues', 
                xticklabels=['No Sub', 'Subscribed'], 
                yticklabels=['No Sub', 'Subscribed'])
    plt.xlabel('Predicted Label', fontsize=12)
    plt.ylabel('True Label', fontsize=12)
    plt.title('Confusion Matrix', fontsize=14, fontweight='bold')
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()

def plot_feature_importance(model, save_path, top_n=15):
    """
    Extracts and plots feature importances from a tree-based model or coefficients from a linear model.
    """
    preprocessor = model.named_steps['preprocessor']
    classifier = model.named_steps['classifier']
    feature_names = get_feature_names(preprocessor)

    # Detect model type and fetch weight metric
    if hasattr(classifier, 'feature_importances_'):
        importances = classifier.feature_importances_
    elif hasattr(classifier, 'coef_'):
        importances = np.abs(classifier.coef_[0])
    else:
        print("Classifier does not support feature importances or coefficients.")
        return

    # Ensure length of importances matches feature names
    if len(importances) != len(feature_names):
        print(f"Warning: size mismatch between importances ({len(importances)}) and feature names ({len(feature_names)}).")
        return

    # Sort importances
    indices = np.argsort(importances)[::-1]
    
    # Take top N
    sorted_features = [feature_names[i] for i in indices[:top_n]]
    sorted_importances = [importances[i] for i in indices[:top_n]]

    plt.figure(figsize=(10, 6), dpi=150)
    sns.barplot(x=sorted_importances, y=sorted_features, palette='viridis')
    plt.xlabel('Importance Score / Coefficient Magnitude', fontsize=12)
    plt.ylabel('Features', fontsize=12)
    plt.title(f'Top {top_n} Feature Importances', fontsize=14, fontweight='bold')
    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, bbox_inches='tight')
    plt.close()
